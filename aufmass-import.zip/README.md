# Aufmaß-Import: MalerAufmaß Pro → Die Maler sind los

## Was das ist

`aufmass-import.js` ist ein einsatzbereites Express-Router-Modul, das die
`...-Handwerker-App-Uebergabe.json`-Datei entgegennimmt, die MalerAufmaß Pro
bereits heute erzeugen kann (Button in der Aufmaß-Oberfläche, Format
`de.maleraufmass.exchange/1.0`), und daraus automatisch Kunde, Projekt und
Angebot mit allen Aufmaß-Positionen anlegt.

## Status

- Die Kernlogik ist mit `test-harness.js` end-zu-Ende getestet (4 Szenarien:
  erfolgreicher Import, Kundenwiederverwendung, falsches Schema, fehlende
  Datei) – alle grün.
- **Nicht getestet gegen euer echtes Backend**, weil mir der Code dazu nicht
  vorliegt. Alle mit `// TODO SCHEMA` markierten Stellen in
  `aufmass-import.js` müsst ihr an eure tatsächlichen Tabellen-/Spaltennamen
  anpassen (Kunden-, Projekte-, Angebote-Tabelle).

## Einbindung

1. Abhängigkeit installieren (falls noch nicht vorhanden):
   ```bash
   npm install multer
   ```
2. Datei `aufmass-import.js` in euer Backend-Verzeichnis kopieren.
3. In eurer `server.js` (oder wo die Routen registriert werden):
   ```js
   const aufmassImportRouter = require('./aufmass-import');
   app.use('/api/aufmass', aufmassImportRouter(db, requireAuth, requireRole));
   ```
   `db` = eure bestehende better-sqlite3-Instanz, `requireAuth` / `requireRole`
   = eure vorhandenen Auth-Middlewares (Namen ggf. anpassen).
4. Die `// TODO SCHEMA`-Stellen in `aufmass-import.js` an eure echten
   Tabellen-/Spaltennamen anpassen (Kunden, Projekte, Angebote,
   Angebotspositionen).
5. Im Frontend einen einfachen Upload-Dialog ergänzen, der die
   `.json`-Datei als `multipart/form-data` mit Feldname `manifest` an
   `POST /api/aufmass/import` sendet.

## Ablauf für Marcus im Alltag

1. In MalerAufmaß Pro ein Aufmaß fertigstellen.
2. Auf "Handwerker-App-Übergabe" exportieren → `.json`-Datei wird
   heruntergeladen.
3. In "Die Maler sind los" den neuen Upload-Dialog öffnen, Datei auswählen.
4. Kunde, Projekt und Angebot mit allen Positionen sind automatisch
   angelegt. Preise müsst ihr wie gewohnt im Angebot ergänzen (die kommen
   aus dem Aufmaß nicht mit, nur Mengen/Einheiten).

## Bekannte Grenzen dieser ersten Version

- Kundenzuordnung erfolgt nur über exakten Namensabgleich. Tippfehler oder
  leicht abweichende Schreibweisen erzeugen einen zweiten, doppelten Kunden
  (markiert mit `needs_review`, aber nicht automatisch zusammengeführt).
- Es gibt noch keinen Schutz gegen doppelten Import derselben Datei
  (`externe_id` wird gespeichert, aber nicht auf Duplikate geprüft) – das
  wäre ein guter nächster Ausbauschritt.
- Preise/Einheitspreise sind bewusst nicht Teil des Imports.
