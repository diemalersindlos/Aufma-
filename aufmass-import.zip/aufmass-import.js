/**
 * aufmass-import.js
 *
 * Nimmt die "...-Handwerker-App-Uebergabe.json"-Datei aus MalerAufmaß Pro
 * entgegen (Schema "de.maleraufmass.exchange/1.0", erzeugt von
 * lib/pro-workflow.ts -> buildIntegrationManifest) und legt daraus in
 * "Die Maler sind los" automatisch einen Kunden, ein Projekt und ein
 * Angebot mit den Aufmaß-Positionen an.
 *
 * WICHTIG: Dies ist eine EINSATZBEREITE VORLAGE, keine fertige Integration.
 * Ich kenne eure tatsächlichen Tabellen-/Spaltennamen für Kunden, Projekte
 * und Angebote nicht (der Backend-Code lag mir nicht vor). Alle Stellen,
 * die ihr an euer echtes Schema anpassen müsst, sind mit "// TODO SCHEMA"
 * markiert. Die Grundstruktur (Auth-Check, Rollen, Transaktion, Mapping)
 * kannst du unverändert übernehmen.
 *
 * Einbindung in eure bestehende Express-App (z.B. server.js):
 *
 *   const aufmassImportRouter = require('./aufmass-import');
 *   app.use('/api/aufmass', aufmassImportRouter(db, requireAuth, requireRole));
 *
 * ...wobei `db` eure bestehende better-sqlite3-Instanz ist und
 * `requireAuth` / `requireRole` eure vorhandenen Auth-Middlewares sind
 * (passt die Namen unten an, falls sie anders heißen).
 */

const express = require('express');
const multer = require('multer');
const crypto = require('crypto');

const upload = multer({
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB reicht für ein Aufmaß-Manifest bei weitem
  fileFilter: (_req, file, callback) => {
    if (file.mimetype !== 'application/json' && !file.originalname.endsWith('.json')) {
      return callback(new Error('Bitte eine .json-Übergabedatei aus MalerAufmaß Pro hochladen.'));
    }
    callback(null, true);
  },
});

const EXPECTED_SCHEMA = 'de.maleraufmass.exchange/1.0';

function parseManifest(buffer) {
  let manifest;
  try {
    manifest = JSON.parse(buffer.toString('utf-8'));
  } catch {
    throw new HttpError(400, 'Die Datei ist kein gültiges JSON.');
  }
  if (manifest.schema !== EXPECTED_SCHEMA) {
    throw new HttpError(
      400,
      `Unbekanntes Übergabeformat "${manifest.schema ?? 'unbekannt'}". Erwartet: ${EXPECTED_SCHEMA}. ` +
        'Vermutlich stammt die Datei aus einer neueren/älteren MalerAufmaß-Pro-Version - bitte Format prüfen.',
    );
  }
  if (!manifest.project || typeof manifest.project !== 'object') {
    throw new HttpError(400, 'Der Übergabedatei fehlen die Projekt-Stammdaten.');
  }
  if (!Array.isArray(manifest.quantities)) {
    throw new HttpError(400, 'Der Übergabedatei fehlen die Aufmaß-Positionen.');
  }
  return manifest;
}

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

/**
 * Sucht einen bestehenden Kunden per Name (case-insensitive, exakter
 * Treffer). Findet er keinen, legt er einen neuen, unvollständigen
 * Kundendatensatz an (nur Name bekannt) und markiert ihn zur Nachpflege.
 *
 * // TODO SCHEMA: Tabellen-/Spaltennamen an euer echtes "kunden"-Schema
 * anpassen (z.B. falls Adresse in separaten Spalten liegt statt einem Feld).
 */
function findOrCreateKunde(db, customerName) {
  const trimmedName = (customerName || '').trim();
  if (!trimmedName) {
    throw new HttpError(400, 'Die Übergabedatei enthält keinen Kundennamen.');
  }

  const existing = db
    .prepare('SELECT id FROM kunden WHERE LOWER(name) = LOWER(?) LIMIT 1') // TODO SCHEMA
    .get(trimmedName);
  if (existing) return { kundeId: existing.id, created: false };

  const info = db
    .prepare(
      `INSERT INTO kunden (name, needs_review, created_at) -- TODO SCHEMA
       VALUES (?, 1, datetime('now'))`,
    )
    .run(trimmedName);
  return { kundeId: info.lastInsertRowid, created: true };
}

/**
 * Legt ein neues Projekt an, das über eine externe Referenz eindeutig auf
 * das MalerAufmaß-Pro-Projekt zurückverweist (verhindert Doppelimporte).
 *
 * // TODO SCHEMA: Spaltennamen an euer echtes "projekte"-Schema anpassen.
 */
function createProjekt(db, kundeId, project) {
  const info = db
    .prepare(
      `INSERT INTO projekte (kunde_id, titel, adresse, referenz, quelle, externe_id, created_at) -- TODO SCHEMA
       VALUES (?, ?, ?, ?, 'maleraufmass-pro', ?, datetime('now'))`,
    )
    .run(kundeId, project.title || 'Ohne Titel', project.address || '', project.reference || '', project.id || null);
  return info.lastInsertRowid;
}

/**
 * Legt ein Angebot mit den Aufmaß-Positionen als Angebotspositionen an.
 * `quantity` aus dem Manifest ist bereits das fertig berechnete Ergebnis
 * (Aufmaß minus Abzüge) - direkt als Menge übernehmbar.
 *
 * // TODO SCHEMA: Tabellen-/Spaltennamen an euer echtes
 * "angebote"/"angebot_positionen"-Schema anpassen, inkl. Preisfeldern
 * (Einheitspreis/Gesamtpreis kommen aus dem Aufmaß nicht mit - die müsst
 * ihr wie gewohnt im Angebot ergänzen).
 */
function createAngebotMitPositionen(db, projektId, quantities) {
  const angebotInfo = db
    .prepare(
      `INSERT INTO angebote (projekt_id, status, created_at) -- TODO SCHEMA
       VALUES (?, 'entwurf', datetime('now'))`,
    )
    .run(projektId);
  const angebotId = angebotInfo.lastInsertRowid;

  const insertPosition = db.prepare(
    `INSERT INTO angebot_positionen -- TODO SCHEMA
       (angebot_id, raum, bezeichnung, formel, menge, einheit, kategorie, externe_position_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
  );

  const insertMany = db.transaction((rows) => {
    for (const row of rows) {
      insertPosition.run(
        angebotId,
        row.room ?? '',
        row.description ?? '',
        row.formula ?? '',
        Number.isFinite(row.quantity) ? row.quantity : 0,
        row.unit ?? '',
        row.category ?? '',
        row.id ?? null,
      );
    }
  });
  insertMany(quantities);

  return angebotId;
}

/**
 * @param {import('better-sqlite3').Database} db
 * @param {import('express').RequestHandler} requireAuth - eure bestehende JWT-Middleware
 * @param {(...roles: string[]) => import('express').RequestHandler} requireRole - eure bestehende Rollen-Middleware
 */
module.exports = function createAufmassImportRouter(db, requireAuth, requireRole) {
  const router = express.Router();

  // Nur "chef" und "buero" dürfen Angebote anlegen - analog zu den
  // bestehenden Rechten für das Angebote-Modul.
  router.post(
    '/import',
    requireAuth,
    requireRole('chef', 'buero'),
    upload.single('manifest'),
    (req, res) => {
      try {
        if (!req.file) {
          throw new HttpError(400, 'Keine Datei empfangen. Feldname muss "manifest" sein.');
        }
        const manifest = parseManifest(req.file.buffer);

        const importRun = db.transaction(() => {
          const { kundeId, created: kundeCreated } = findOrCreateKunde(db, manifest.project.customer);
          const projektId = createProjekt(db, kundeId, manifest.project);
          const angebotId = createAngebotMitPositionen(db, projektId, manifest.quantities);
          return { kundeId, kundeCreated, projektId, angebotId };
        });

        const result = importRun();

        res.json({
          ok: true,
          importId: crypto.randomUUID(),
          kundeId: result.kundeId,
          kundeMussNachgepflegtWerden: result.kundeCreated,
          projektId: result.projektId,
          angebotId: result.angebotId,
          positionenUebernommen: manifest.quantities.length,
          hinweis:
            result.kundeCreated
              ? 'Es wurde ein neuer Kunde nur mit Namen angelegt - bitte Adresse/Kontakt im Kundenmodul ergänzen.'
              : 'Bestehender Kunde wurde dem Projekt zugeordnet.',
        });
      } catch (error) {
        const status = error instanceof HttpError ? error.status : 500;
        if (status === 500) console.error('Aufmaß-Import fehlgeschlagen', error);
        res.status(status).json({ ok: false, error: error.message || 'Import fehlgeschlagen.' });
      }
    },
  );

  return router;
};

/**
 * Beispiel für ein passendes DB-Schema (SQLite), falls ihr die Tabellen
 * "angebot_positionen" / "needs_review"-Spalte noch nicht habt:
 *
 *   ALTER TABLE kunden ADD COLUMN needs_review INTEGER NOT NULL DEFAULT 0;
 *
 *   ALTER TABLE projekte ADD COLUMN quelle TEXT;
 *   ALTER TABLE projekte ADD COLUMN externe_id TEXT;
 *
 *   CREATE TABLE IF NOT EXISTS angebot_positionen (
 *     id INTEGER PRIMARY KEY AUTOINCREMENT,
 *     angebot_id INTEGER NOT NULL REFERENCES angebote(id),
 *     raum TEXT,
 *     bezeichnung TEXT,
 *     formel TEXT,
 *     menge REAL,
 *     einheit TEXT,
 *     kategorie TEXT,
 *     externe_position_id TEXT
 *   );
 *
 * Passt die Spaltentypen/-namen an das an, was in euren echten Tabellen
 * bereits existiert - das hier ist nur eine Orientierung.
 */
