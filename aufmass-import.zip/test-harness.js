// Testet aufmass-import.js Ende-zu-Ende, ohne echte express/multer/better-sqlite3
// Pakete zu benötigen (im Sandbox-Netzwerk nicht installierbar). Simuliert nur
// die exakten API-Aufrufe, die aufmass-import.js tatsächlich verwendet.

const Module = require('module');
const assert = require('assert/strict');

// --- Fake "express" -------------------------------------------------------
const registeredRoutes = [];
function fakeExpress() {}
fakeExpress.Router = function Router() {
  return {
    post(path, ...handlers) {
      registeredRoutes.push({ path, handlers });
    },
  };
};

// --- Fake "multer" ---------------------------------------------------------
function fakeMulter(_options) {
  return {
    single(_fieldName) {
      // In echten Tests setzen wir req.file bereits selbst; hier reicht ein
      // Passthrough-Middleware.
      return (_req, _res, next) => next();
    },
  };
}
fakeMulter.MulterError = class MulterError extends Error {};

// --- Modul-Loader umleiten --------------------------------------------------
const originalResolve = Module._resolveFilename;
Module._resolveFilename = function (request, ...rest) {
  if (request === 'express' || request === 'multer') return request;
  return originalResolve.call(this, request, ...rest);
};
const originalLoad = Module._load;
Module._load = function (request, ...rest) {
  if (request === 'express') return fakeExpress;
  if (request === 'multer') return fakeMulter;
  return originalLoad.call(this, request, ...rest);
};

// --- Minimale In-Memory-"better-sqlite3"-Simulation -------------------------
function createFakeDb() {
  const tables = { kunden: [], projekte: [], angebote: [], angebot_positionen: [] };
  let autoId = 1;

  function normalizeSql(sql) {
    return sql.replace(/\s+/g, ' ').trim();
  }

  const db = {
    prepare(sql) {
      const normalized = normalizeSql(sql);
      return {
        get(name) {
          if (normalized.startsWith('SELECT id FROM kunden')) {
            const match = tables.kunden.find((row) => row.name.toLowerCase() === String(name).toLowerCase());
            return match ? { id: match.id } : undefined;
          }
          throw new Error(`Unbekannte GET-Query im Test-Stub: ${normalized}`);
        },
        run(...args) {
          if (normalized.startsWith('INSERT INTO kunden')) {
            const [name] = args;
            const id = autoId++;
            tables.kunden.push({ id, name, needs_review: 1 });
            return { lastInsertRowid: id };
          }
          if (normalized.startsWith('INSERT INTO projekte')) {
            const [kundeId, titel, adresse, referenz, externeId] = args;
            const id = autoId++;
            tables.projekte.push({ id, kundeId, titel, adresse, referenz, quelle: 'maleraufmass-pro', externeId });
            return { lastInsertRowid: id };
          }
          if (normalized.startsWith('INSERT INTO angebote')) {
            const [projektId] = args;
            const id = autoId++;
            tables.angebote.push({ id, projektId, status: 'entwurf' });
            return { lastInsertRowid: id };
          }
          if (normalized.startsWith('INSERT INTO angebot_positionen')) {
            const [angebotId, raum, bezeichnung, formel, menge, einheit, kategorie, externePositionId] = args;
            const id = autoId++;
            tables.angebot_positionen.push({ id, angebotId, raum, bezeichnung, formel, menge, einheit, kategorie, externePositionId });
            return { lastInsertRowid: id };
          }
          throw new Error(`Unbekannte RUN-Query im Test-Stub: ${normalized}`);
        },
      };
    },
    transaction(fn) {
      // better-sqlite3 führt die Funktion synchron aus und gibt eine
      // aufrufbare Wrapper-Funktion zurück - für den Test reicht Passthrough.
      return (...args) => fn(...args);
    },
    __tables: tables,
  };
  return db;
}

// --- Test ausführen ----------------------------------------------------------
const createAufmassImportRouter = require('./aufmass-import.js');

const fakeManifest = {
  schema: 'de.maleraufmass.exchange/1.0',
  project: { id: 'proj_abc123', title: 'Musterhaus Güstrow', customer: 'Familie Beispiel', address: 'Teststraße 1, 18273 Güstrow', reference: 'AUF-2026-014' },
  review: { status: 'released', revision: 3, releasedAt: '2026-09-01T10:00:00.000Z', releaseCode: 'REL-014' },
  quantities: [
    { id: 'row_1', measurementId: 'room_1', room: 'Wohnzimmer', description: 'Bodenfläche', formula: '24.50 m² × 1', gross: 24.5, deduction: 0, quantity: 24.5, unit: 'm²', category: 'Boden' },
    { id: 'row_2', measurementId: 'room_1', room: 'Wohnzimmer', description: 'Wandfläche', formula: '19.80 m × 2.50 m × 1', gross: 49.5, deduction: 3.2, quantity: 46.3, unit: 'm²', category: 'Wand' },
    { id: 'row_3', measurementId: 'room_2', room: 'Flur', description: 'Bodenfläche', formula: '8.10 m² × 1', gross: 8.1, deduction: 0, quantity: 8.1, unit: 'm²', category: 'Boden' },
  ],
};

function runImportTest() {
  const db = createFakeDb();
  const requireAuth = (_req, _res, next) => next();
  const requireRole = (..._roles) => (_req, _res, next) => next();

  registeredRoutes.length = 0;
  createAufmassImportRouter(db, requireAuth, requireRole);
  assert.equal(registeredRoutes.length, 1, 'Es muss genau eine Route registriert worden sein.');
  const importRoute = registeredRoutes[0];
  assert.equal(importRoute.path, '/import');
  const finalHandler = importRoute.handlers.at(-1);

  const req = { file: { buffer: Buffer.from(JSON.stringify(fakeManifest)) } };
  let statusCode = null;
  let jsonBody = null;
  const res = {
    status(code) { statusCode = code; return this; },
    json(body) { jsonBody = body; return this; },
  };

  finalHandler(req, res);

  assert.equal(statusCode, null, 'Bei Erfolg darf kein Fehlerstatus gesetzt werden.');
  assert.equal(jsonBody.ok, true);
  assert.equal(jsonBody.positionenUebernommen, 3);
  assert.equal(jsonBody.kundeMussNachgepflegtWerden, true, 'Neuer Kunde muss als nachpflegebedürftig markiert werden.');

  assert.equal(db.__tables.kunden.length, 1);
  assert.equal(db.__tables.kunden[0].name, 'Familie Beispiel');
  assert.equal(db.__tables.projekte.length, 1);
  assert.equal(db.__tables.projekte[0].titel, 'Musterhaus Güstrow');
  assert.equal(db.__tables.projekte[0].externeId, 'proj_abc123');
  assert.equal(db.__tables.angebote.length, 1);
  assert.equal(db.__tables.angebot_positionen.length, 3);
  assert.equal(db.__tables.angebot_positionen[1].menge, 46.3);
  assert.equal(db.__tables.angebot_positionen[1].kategorie, 'Wand');

  console.log('Test 1 (Neuer Kunde, vollständiger Import) erfolgreich:', JSON.stringify(jsonBody, null, 2));

  // --- Zweiter Import mit demselben Kundennamen: Kunde darf nicht doppelt
  // angelegt werden (case-insensitive Treffer).
  const req2 = { file: { buffer: Buffer.from(JSON.stringify({ ...fakeManifest, project: { ...fakeManifest.project, id: 'proj_xyz789', title: 'Zweitprojekt' } })) } };
  let statusCode2 = null;
  let jsonBody2 = null;
  const res2 = {
    status(code) { statusCode2 = code; return this; },
    json(body) { jsonBody2 = body; return this; },
  };
  finalHandler(req2, res2);
  assert.equal(statusCode2, null);
  assert.equal(jsonBody2.kundeMussNachgepflegtWerden, false, 'Bestehender Kunde darf nicht erneut als neu markiert werden.');
  assert.equal(db.__tables.kunden.length, 1, 'Derselbe Kundenname darf keinen zweiten Kunden anlegen.');
  assert.equal(db.__tables.projekte.length, 2, 'Ein zweites Projekt für denselben Kunden muss trotzdem angelegt werden.');
  console.log('Test 2 (Bestehender Kunde wiederverwendet) erfolgreich.');

  // --- Fehlerfall: falsches Schema ------------------------------------------
  const req3 = { file: { buffer: Buffer.from(JSON.stringify({ schema: 'irgendwas/9.9', project: {}, quantities: [] })) } };
  let statusCode3 = null;
  let jsonBody3 = null;
  const res3 = {
    status(code) { statusCode3 = code; return this; },
    json(body) { jsonBody3 = body; return this; },
  };
  finalHandler(req3, res3);
  assert.equal(statusCode3, 400, 'Falsches Schema muss mit 400 abgelehnt werden.');
  assert.equal(jsonBody3.ok, false);
  console.log('Test 3 (falsches Schema wird abgelehnt) erfolgreich:', jsonBody3.error);

  // --- Fehlerfall: keine Datei ------------------------------------------------
  const req4 = {};
  let statusCode4 = null;
  let jsonBody4 = null;
  const res4 = {
    status(code) { statusCode4 = code; return this; },
    json(body) { jsonBody4 = body; return this; },
  };
  finalHandler(req4, res4);
  assert.equal(statusCode4, 400);
  assert.equal(jsonBody4.ok, false);
  console.log('Test 4 (fehlende Datei wird abgelehnt) erfolgreich:', jsonBody4.error);
}

runImportTest();
console.log('\nAlle Import-Tests erfolgreich.');
